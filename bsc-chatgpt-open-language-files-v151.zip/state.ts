// src/core/state.ts
import { z } from "zod";

/**
 * Canonical step IDs (expand later as you add steps)
 */
export const CANONICAL_STEPS = [
  "step_0",
  "dream",
  "purpose",
  "bigwhy",
  "role",
  "entity",
  "strategy",
  "targetgroup",
  "productsservices",
  "rulesofthegame",
  "presentation",
] as const;

export type CanonicalStepId = (typeof CANONICAL_STEPS)[number];

export function isCanonicalStepId(x: unknown): x is CanonicalStepId {
  return typeof x === "string" && (CANONICAL_STEPS as readonly string[]).includes(x);
}

export const BoolStringZod = z.enum(["true", "false"]);
export type BoolString = z.infer<typeof BoolStringZod>;
export const DreamRuntimeModeZod = z.enum([
  "self",
  "builder_collect",
  "builder_scoring",
  "builder_refine",
]);
export type DreamRuntimeMode = z.infer<typeof DreamRuntimeModeZod>;
export const PROVISIONAL_SOURCES = [
  "user_input",
  "wording_pick",
  "action_route",
  "system_generated",
] as const;
export const ProvisionalSourceZod = z.enum(PROVISIONAL_SOURCES);
export type ProvisionalSource = z.infer<typeof ProvisionalSourceZod>;
export const LANGUAGE_SOURCES = [
  "",
  "explicit_override",
  "locale_hint",
  "message_detect",
  "persisted",
] as const;
export const LanguageSourceZod = z.enum(LANGUAGE_SOURCES);
export type LanguageSource = z.infer<typeof LanguageSourceZod>;

export function normalizeStateLanguageSource(raw: unknown): LanguageSource {
  const source = String(raw ?? "").trim();
  if (
    source === "explicit_override" ||
    source === "locale_hint" ||
    source === "message_detect" ||
    source === "persisted"
  ) {
    return source;
  }
  // Legacy transport sources were mistakenly persisted into state.language_source.
  if (source === "openai_locale" || source === "webplus_i18n" || source === "request_header") {
    return "locale_hint";
  }
  return "";
}
export const UI_STRINGS_STATUSES = ["ready", "pending", "error"] as const;
export const UiStringsStatusZod = z.enum(UI_STRINGS_STATUSES);
export type UiStringsStatus = z.infer<typeof UiStringsStatusZod>;
export const UI_BOOTSTRAP_STATUSES = ["init", "awaiting_locale", "ready"] as const;
export const UiBootstrapStatusZod = z.enum(UI_BOOTSTRAP_STATUSES);
export type UiBootstrapStatus = z.infer<typeof UiBootstrapStatusZod>;
export const UI_GATE_STATUSES = ["waiting_locale", "ready"] as const;
export const UiGateStatusZod = z.enum(UI_GATE_STATUSES);
export type UiGateStatus = z.infer<typeof UiGateStatusZod>;
export const UI_GATE_REASONS = ["", "translation_pending", "translation_retry"] as const;
export const UiGateReasonZod = z.enum(UI_GATE_REASONS);
export type UiGateReason = z.infer<typeof UiGateReasonZod>;
export const UI_TRANSLATION_MODES = ["critical_first", "full"] as const;
export const UiTranslationModeZod = z.enum(UI_TRANSLATION_MODES);
export type UiTranslationMode = z.infer<typeof UiTranslationModeZod>;

/**
 * CanvasState (canoniek)
 * - Alles string-based (parity-friendly)
 * - Geen nulls
 * - Room for future fields without breaking changes
 */
export const CanvasStateZod = z.object({
  // versioning/migrations
  state_version: z.string(),

  // routing
  current_step: z.string(), // should be canonical, but stored as string for resilience
  active_specialist: z.string(),
  intro_shown_for_step: z.string(), // stores last step-id for which intro was shown
  intro_shown_session: BoolStringZod,

  // language handling (multi-language UX)
  language: z.string(),
  language_locked: BoolStringZod, // once set from a meaningful user message, we don't auto-flip
  language_override: BoolStringZod, // true only when user explicitly requested a language
  language_source: LanguageSourceZod,
  // UI strings (localized in backend; cached per language)
  ui_strings: z.record(z.string(), z.string()),
  ui_strings_lang: z.string(),
  ui_strings_version: z.string(),
  ui_strings_status: UiStringsStatusZod,
  ui_strings_requested_lang: z.string(),
  ui_bootstrap_status: UiBootstrapStatusZod,
  ui_gate_status: UiGateStatusZod,
  ui_gate_reason: UiGateReasonZod,
  ui_gate_since_ms: z.number().int().nonnegative(),
  ui_translation_mode: UiTranslationModeZod,
  ui_strings_critical_ready: BoolStringZod,
  ui_strings_full_ready: BoolStringZod,
  ui_strings_background_inflight: BoolStringZod,

  // last output (used for proceed triggers / transitions)
  // FIX (Zod v4): record needs key + value schema
  last_specialist_result: z.record(z.string(), z.any()),

  // stable stored lines / finals
  step_0_final: z.string(),
  dream_final: z.string(),
  purpose_final: z.string(),
  bigwhy_final: z.string(),
  role_final: z.string(),
  entity_final: z.string(),
  strategy_final: z.string(),
  targetgroup_final: z.string(),
  productsservices_final: z.string(),
  rulesofthegame_final: z.string(),
  presentation_brief_final: z.string(),

  // staged per-step value (chosen wording before explicit next-step confirm)
  provisional_by_step: z.record(z.string(), z.string()),
  provisional_source_by_step: z.record(z.string(), ProvisionalSourceZod),
  __dream_runtime_mode: DreamRuntimeModeZod,
  dream_builder_statements: z.array(z.string()),

  // shared convenience fields
  business_name: z.string(),
  quote_last_by_step: z.record(z.string(), z.string()),

  // reserved
  summary_target: z.string(),
});

export type CanvasState = z.infer<typeof CanvasStateZod>;

/**
 * Current state schema version
 * Bump when you change defaults/fields in a way that needs migration.
 */
export const CURRENT_STATE_VERSION = "10";

/**
 * Hard defaults (no nulls)
 */
export function getDefaultState(): CanvasState {
  return {
    state_version: CURRENT_STATE_VERSION,

    current_step: "step_0",
    active_specialist: "",
    intro_shown_for_step: "",
    intro_shown_session: "false",

    language: "",
    language_locked: "false",
    language_override: "false",
    language_source: "",
    ui_strings: {},
    ui_strings_lang: "",
    ui_strings_version: "",
    ui_strings_status: "ready",
    ui_strings_requested_lang: "",
    ui_bootstrap_status: "init",
    ui_gate_status: "ready",
    ui_gate_reason: "",
    ui_gate_since_ms: 0,
    ui_translation_mode: "full",
    ui_strings_critical_ready: "false",
    ui_strings_full_ready: "false",
    ui_strings_background_inflight: "false",

    last_specialist_result: {},

    step_0_final: "",
    dream_final: "",
    purpose_final: "",
    bigwhy_final: "",
    role_final: "",
    entity_final: "",
    strategy_final: "",
    targetgroup_final: "",
    productsservices_final: "",
    rulesofthegame_final: "",
    presentation_brief_final: "",

    provisional_by_step: {},
    provisional_source_by_step: {},
    __dream_runtime_mode: "self",
    dream_builder_statements: [],

    business_name: "TBD",
    quote_last_by_step: {},

    summary_target: "unknown",
  };
}

/**
 * Normalize any incoming raw state to canonical shape:
 * - Ensures required keys exist
 * - Coerces types to safe strings/bool-strings
 * - Clamps invalid current_step to step_0
 * - Never returns nulls
 */
export function normalizeState(raw: unknown): CanvasState {
  const d = getDefaultState();

  const r: any = typeof raw === "object" && raw !== null ? raw : {};

  const state_version = String(r.state_version ?? d.state_version).trim() || d.state_version;

  const current_step_raw = String(r.current_step ?? d.current_step).trim() || d.current_step;
  const current_step = isCanonicalStepId(current_step_raw) ? current_step_raw : "step_0";

  const active_specialist = String(r.active_specialist ?? d.active_specialist);
  const intro_shown_for_step = String(r.intro_shown_for_step ?? d.intro_shown_for_step);

  const intro_shown_session_raw = String(r.intro_shown_session ?? d.intro_shown_session).trim();
  const intro_shown_session: BoolString = intro_shown_session_raw === "true" ? "true" : "false";

  const language = String(r.language ?? d.language).trim().toLowerCase();
  const language_locked_raw = String(r.language_locked ?? d.language_locked).trim();
  const language_locked: BoolString = language_locked_raw === "true" ? "true" : "false";
  const language_override_raw = String(r.language_override ?? d.language_override).trim();
  const language_override: BoolString = language_override_raw === "true" ? "true" : "false";
  const language_source = normalizeStateLanguageSource((r as any).language_source ?? d.language_source);
  const ui_strings_raw =
    typeof (r as any).ui_strings === "object" && (r as any).ui_strings !== null
      ? (r as any).ui_strings
      : d.ui_strings;
  const ui_strings = Object.fromEntries(
    Object.entries(ui_strings_raw || {}).map(([k, v]) => [String(k), String(v ?? "")])
  );
  const ui_strings_lang = String((r as any).ui_strings_lang ?? d.ui_strings_lang).trim().toLowerCase();
  const ui_strings_version = String((r as any).ui_strings_version ?? d.ui_strings_version).trim();
  const ui_strings_status_raw = String((r as any).ui_strings_status ?? d.ui_strings_status).trim();
  const ui_strings_status: UiStringsStatus =
    ui_strings_status_raw === "pending" || ui_strings_status_raw === "error" ? ui_strings_status_raw : "ready";
  const ui_strings_requested_lang = String((r as any).ui_strings_requested_lang ?? d.ui_strings_requested_lang)
    .trim()
    .toLowerCase();
  const ui_bootstrap_status_raw = String((r as any).ui_bootstrap_status ?? d.ui_bootstrap_status).trim();
  const ui_bootstrap_status: UiBootstrapStatus =
    ui_bootstrap_status_raw === "awaiting_locale" || ui_bootstrap_status_raw === "ready"
      ? ui_bootstrap_status_raw
      : "init";
  const ui_gate_status_raw = String((r as any).ui_gate_status ?? d.ui_gate_status).trim();
  const ui_gate_status: UiGateStatus =
    ui_gate_status_raw === "waiting_locale" || ui_gate_status_raw === "ready"
      ? ui_gate_status_raw
      : "ready";
  const ui_gate_reason_raw = String((r as any).ui_gate_reason ?? d.ui_gate_reason).trim();
  const ui_gate_reason: UiGateReason =
    ui_gate_reason_raw === "translation_pending" || ui_gate_reason_raw === "translation_retry"
      ? ui_gate_reason_raw
      : "";
  const ui_gate_since_raw = Number((r as any).ui_gate_since_ms ?? d.ui_gate_since_ms);
  const ui_gate_since_ms = Number.isFinite(ui_gate_since_raw) && ui_gate_since_raw >= 0
    ? Math.trunc(ui_gate_since_raw)
    : 0;
  const ui_translation_mode_raw = String((r as any).ui_translation_mode ?? d.ui_translation_mode).trim();
  const ui_translation_mode: UiTranslationMode =
    ui_translation_mode_raw === "critical_first" || ui_translation_mode_raw === "full"
      ? ui_translation_mode_raw
      : "full";
  const ui_strings_critical_ready_raw = String(
    (r as any).ui_strings_critical_ready ?? d.ui_strings_critical_ready
  ).trim();
  const ui_strings_critical_ready: BoolString = ui_strings_critical_ready_raw === "true" ? "true" : "false";
  const ui_strings_full_ready_raw = String((r as any).ui_strings_full_ready ?? d.ui_strings_full_ready).trim();
  const ui_strings_full_ready: BoolString = ui_strings_full_ready_raw === "true" ? "true" : "false";
  const ui_strings_background_inflight_raw = String(
    (r as any).ui_strings_background_inflight ?? d.ui_strings_background_inflight
  ).trim();
  const ui_strings_background_inflight: BoolString =
    ui_strings_background_inflight_raw === "true" ? "true" : "false";

  const last_specialist_result =
    typeof r.last_specialist_result === "object" && r.last_specialist_result !== null
      ? (r.last_specialist_result as Record<string, any>)
      : {};

  const step_0_final = String(r.step_0_final ?? d.step_0_final);
  const dream_final = String(r.dream_final ?? d.dream_final);
  const purpose_final = String(r.purpose_final ?? d.purpose_final);
  const bigwhy_final = String(r.bigwhy_final ?? d.bigwhy_final);
  const role_final = String(r.role_final ?? d.role_final);
  const entity_final = String(r.entity_final ?? d.entity_final);
  const strategy_final = String(r.strategy_final ?? d.strategy_final);
  const targetgroup_final = String(r.targetgroup_final ?? d.targetgroup_final);
  const productsservices_final = String(r.productsservices_final ?? d.productsservices_final);
  const rulesofthegame_final = String(r.rulesofthegame_final ?? d.rulesofthegame_final);
  const presentation_brief_final = String(r.presentation_brief_final ?? d.presentation_brief_final);
  const provisional_raw =
    typeof r.provisional_by_step === "object" && r.provisional_by_step !== null
      ? (r.provisional_by_step as Record<string, unknown>)
      : {};
  const provisional_by_step = Object.fromEntries(
    Object.entries(provisional_raw).map(([k, v]) => [String(k), String(v ?? "").trim()])
  );
  const provisional_source_raw =
    typeof r.provisional_source_by_step === "object" && r.provisional_source_by_step !== null
      ? (r.provisional_source_by_step as Record<string, unknown>)
      : {};
  const provisional_source_by_step = Object.fromEntries(
    Object.entries(provisional_source_raw)
      .map(([k, v]) => {
        const source = String(v || "").trim();
        if (
          source !== "user_input" &&
          source !== "wording_pick" &&
          source !== "action_route" &&
          source !== "system_generated"
        ) {
          return null;
        }
        return [String(k), source] as const;
      })
      .filter((entry): entry is readonly [string, "user_input" | "wording_pick" | "action_route" | "system_generated"] => Boolean(entry))
  );
  const dreamRuntimeModeRaw = String((r as any).__dream_runtime_mode ?? d.__dream_runtime_mode).trim();
  const __dream_runtime_mode: DreamRuntimeMode =
    dreamRuntimeModeRaw === "builder_collect" ||
    dreamRuntimeModeRaw === "builder_scoring" ||
    dreamRuntimeModeRaw === "builder_refine"
      ? dreamRuntimeModeRaw
      : "self";
  const dreamBuilderStatementsRaw = Array.isArray((r as any).dream_builder_statements)
    ? ((r as any).dream_builder_statements as unknown[])
    : [];
  const dream_builder_statements = dreamBuilderStatementsRaw
    .map((line) => String(line || "").trim())
    .filter(Boolean);

  const business_name = String(r.business_name ?? d.business_name) || "TBD";
  const quote_last_by_step_raw =
    typeof (r as any).quote_last_by_step === "object" && (r as any).quote_last_by_step !== null
      ? ((r as any).quote_last_by_step as Record<string, unknown>)
      : {};
  const quote_last_by_step = Object.fromEntries(
    Object.entries(quote_last_by_step_raw).map(([k, v]) => [String(k), String(v ?? "")])
  );
  const summary_target = String(r.summary_target ?? d.summary_target) || "unknown";

  const normalized: CanvasState = {
    state_version,
    current_step,
    active_specialist,
    intro_shown_for_step,
    intro_shown_session,

    language,
    language_locked,
    language_override,
    language_source,
    ui_strings,
    ui_strings_lang,
    ui_strings_version,
    ui_strings_status,
    ui_strings_requested_lang,
    ui_bootstrap_status,
    ui_gate_status,
    ui_gate_reason,
    ui_gate_since_ms,
    ui_translation_mode,
    ui_strings_critical_ready,
    ui_strings_full_ready,
    ui_strings_background_inflight,

    last_specialist_result,

    step_0_final,
    dream_final,
    purpose_final,
    bigwhy_final,
    role_final,
    entity_final,
    strategy_final,
    targetgroup_final,
    productsservices_final,
    rulesofthegame_final,
    presentation_brief_final,

    provisional_by_step,
    provisional_source_by_step,
    __dream_runtime_mode,
    dream_builder_statements,

    business_name,
    quote_last_by_step,
    summary_target,
  };

  // final Zod check (should always pass)
  return CanvasStateZod.parse(normalized);
}

/**
 * Migrate state from older versions to CURRENT_STATE_VERSION.
 * Keep this function deterministic and side-effect free.
 */
export function migrateState(raw: unknown): CanvasState {
  // First normalize shape and types (safe)
  let s = normalizeState(raw);

  // If already current, done
  if (s.state_version === CURRENT_STATE_VERSION) return s;

  // v9 -> v10: add critical-first translation metadata.
  if (s.state_version === "9") {
    const statusRaw = String((s as any).ui_strings_status ?? "ready").trim();
    const uiStatus = statusRaw === "pending" || statusRaw === "error" ? statusRaw : "ready";
    s = {
      ...s,
      state_version: "10",
      ui_translation_mode: uiStatus === "ready" ? "full" : "critical_first",
      ui_strings_critical_ready: uiStatus === "ready" ? "true" : "false",
      ui_strings_full_ready: uiStatus === "ready" ? "true" : "false",
      ui_strings_background_inflight: uiStatus === "ready" ? "false" : "true",
    };
    return CanvasStateZod.parse(s);
  }

  // v8 -> v9: add locale-ready UI gate metadata.
  if (s.state_version === "8") {
    const statusRaw = String((s as any).ui_strings_status ?? "ready").trim();
    const uiStatus = statusRaw === "pending" || statusRaw === "error" ? statusRaw : "ready";
    const gateStatus: UiGateStatus = uiStatus === "ready" ? "ready" : "waiting_locale";
    const gateReason: UiGateReason =
      gateStatus === "ready"
        ? ""
        : uiStatus === "error"
          ? "translation_retry"
          : "translation_pending";
    const sinceRaw = Number((s as any).ui_gate_since_ms ?? 0);
    const ui_gate_since_ms =
      gateStatus === "ready"
        ? 0
        : Number.isFinite(sinceRaw) && sinceRaw > 0
          ? Math.trunc(sinceRaw)
          : 0;
    s = {
      ...s,
      state_version: "9",
      ui_gate_status: gateStatus,
      ui_gate_reason: gateReason,
      ui_gate_since_ms,
      ui_translation_mode: uiStatus === "ready" ? "full" : "critical_first",
      ui_strings_critical_ready: uiStatus === "ready" ? "true" : "false",
      ui_strings_full_ready: uiStatus === "ready" ? "true" : "false",
      ui_strings_background_inflight: uiStatus === "ready" ? "false" : "true",
    };
    return migrateState(s);
  }

  // v7 -> v8: add UI bootstrap status metadata.
  if (s.state_version === "7") {
    const bootstrapRaw = String((s as any).ui_bootstrap_status ?? "").trim();
    const bootstrapFromStatus = String((s as any).ui_strings_status ?? "ready").trim();
    const ui_bootstrap_status =
      bootstrapRaw === "init" || bootstrapRaw === "awaiting_locale" || bootstrapRaw === "ready"
        ? bootstrapRaw
        : bootstrapFromStatus === "ready"
          ? "ready"
          : "awaiting_locale";
    s = {
      ...s,
      state_version: "8",
      ui_bootstrap_status,
      ui_translation_mode: ui_bootstrap_status === "ready" ? "full" : "critical_first",
      ui_strings_critical_ready: ui_bootstrap_status === "ready" ? "true" : "false",
      ui_strings_full_ready: ui_bootstrap_status === "ready" ? "true" : "false",
      ui_strings_background_inflight: ui_bootstrap_status === "ready" ? "false" : "true",
    };
    return migrateState(s);
  }

  // v6 -> v7: add language source + ui_strings status metadata.
  if (s.state_version === "6") {
    const language_source = normalizeStateLanguageSource((s as any).language_source ?? "");
    const statusRaw = String((s as any).ui_strings_status ?? "ready").trim();
    const ui_strings_status =
      statusRaw === "pending" || statusRaw === "error"
        ? statusRaw
        : "ready";
    s = {
      ...s,
      state_version: "7",
      language_source,
      ui_strings_status,
      ui_strings_requested_lang: String((s as any).ui_strings_requested_lang ?? "").trim().toLowerCase(),
      ui_translation_mode: ui_strings_status === "ready" ? "full" : "critical_first",
      ui_strings_critical_ready: ui_strings_status === "ready" ? "true" : "false",
      ui_strings_full_ready: ui_strings_status === "ready" ? "true" : "false",
      ui_strings_background_inflight: ui_strings_status === "ready" ? "false" : "true",
    };
    return migrateState(s);
  }

  // v5 -> v6: add source map for staged values (legacy staged values default to system_generated).
  if (s.state_version === "5") {
    const staged = typeof (s as any).provisional_by_step === "object" && (s as any).provisional_by_step !== null
      ? ((s as any).provisional_by_step as Record<string, unknown>)
      : {};
    const existingSources =
      typeof (s as any).provisional_source_by_step === "object" && (s as any).provisional_source_by_step !== null
        ? ((s as any).provisional_source_by_step as Record<string, unknown>)
        : {};
    const nextSources: Record<string, ProvisionalSource> = {};
    for (const [stepIdRaw, valueRaw] of Object.entries(staged)) {
      const stepId = String(stepIdRaw || "").trim();
      const value = String(valueRaw || "").trim();
      if (!stepId || !value) continue;
      const existing = String(existingSources[stepId] || "").trim();
      if (
        existing === "user_input" ||
        existing === "wording_pick" ||
        existing === "action_route" ||
        existing === "system_generated"
      ) {
        nextSources[stepId] = existing;
      } else {
        nextSources[stepId] = "system_generated";
      }
    }
    s = {
      ...s,
      state_version: "6",
      provisional_source_by_step: nextSources,
      ui_translation_mode: "full",
      ui_strings_critical_ready: "false",
      ui_strings_full_ready: "false",
      ui_strings_background_inflight: "false",
    };
    return migrateState(s);
  }

  // v4 -> v5: add ui string schema version marker to support deterministic text refresh.
  if (s.state_version === "4") {
    s = {
      ...s,
      state_version: "5",
      ui_strings_version: String((s as any).ui_strings_version ?? "").trim(),
      ui_translation_mode: "full",
      ui_strings_critical_ready: "false",
      ui_strings_full_ready: "false",
      ui_strings_background_inflight: "false",
    };
    return migrateState(s);
  }

  // v3 -> v4: hard reset legacy confirm/proceed sessions (no compatibility layer).
  if (s.state_version === "3") {
    const fresh = getDefaultState();
    s = {
      ...fresh,
      language: String((s as any).language ?? "").trim().toLowerCase(),
      language_locked: String((s as any).language_locked ?? "false") === "true" ? "true" : "false",
      language_override: String((s as any).language_override ?? "false") === "true" ? "true" : "false",
      quote_last_by_step:
        typeof (s as any).quote_last_by_step === "object" && (s as any).quote_last_by_step !== null
          ? Object.fromEntries(
              Object.entries((s as any).quote_last_by_step as Record<string, unknown>).map(([k, v]) => [
                String(k),
                String(v ?? ""),
              ])
            )
          : {},
      ui_strings:
        typeof (s as any).ui_strings === "object" && (s as any).ui_strings !== null
          ? Object.fromEntries(
              Object.entries((s as any).ui_strings as Record<string, unknown>).map(([k, v]) => [
                String(k),
                String(v ?? ""),
              ])
            )
          : {},
      ui_strings_lang: String((s as any).ui_strings_lang ?? "").trim().toLowerCase(),
      ui_strings_version: String((s as any).ui_strings_version ?? "").trim(),
      provisional_by_step: {},
      ui_translation_mode: "full",
      ui_strings_critical_ready: "false",
      ui_strings_full_ready: "false",
      ui_strings_background_inflight: "false",
    };
    return CanvasStateZod.parse(s);
  }

  // v2 -> v3: add targetgroup_final and productsservices_final
  if (s.state_version === "2") {
    s = {
      ...s,
      state_version: "3",
      targetgroup_final: String((s as any).targetgroup_final ?? ""),
      productsservices_final: String((s as any).productsservices_final ?? ""),
    };
    return migrateState(s);
  }

  // v1 -> v2: add missing finals + language fields (defaults)
  s = {
    ...s,
    state_version: "2",
    business_name: s.business_name?.trim() ? s.business_name : "TBD",
    language: String((s as any).language ?? "").trim().toLowerCase(),
    language_locked: String((s as any).language_locked ?? "false") === "true" ? "true" : "false",
    language_override: String((s as any).language_override ?? "false") === "true" ? "true" : "false",
    purpose_final: String((s as any).purpose_final ?? ""),
    bigwhy_final: String((s as any).bigwhy_final ?? ""),
    role_final: String((s as any).role_final ?? ""),
    entity_final: String((s as any).entity_final ?? ""),
    strategy_final: String((s as any).strategy_final ?? ""),
    quote_last_by_step:
      typeof (s as any).quote_last_by_step === "object" && (s as any).quote_last_by_step !== null
        ? Object.fromEntries(
            Object.entries((s as any).quote_last_by_step as Record<string, unknown>).map(([k, v]) => [
              String(k),
              String(v ?? ""),
            ])
          )
        : {},
    rulesofthegame_final: String((s as any).rulesofthegame_final ?? ""),
    presentation_brief_final: String((s as any).presentation_brief_final ?? ""),
    targetgroup_final: "",
    productsservices_final: "",
    ui_translation_mode: "full",
    ui_strings_critical_ready: "false",
    ui_strings_full_ready: "false",
    ui_strings_background_inflight: "false",
  };

  // Recursively migrate to current version if needed
  return migrateState(s);
}

/**
 * Convenience: set current step safely (clamped)
 */
export function setCurrentStep(state: CanvasState, next: string): CanvasState {
  const step = isCanonicalStepId(next) ? next : "step_0";
  return CanvasStateZod.parse({ ...state, current_step: step });
}

/**
 * Convenience: mark that session intro has been shown
 */
export function markSessionIntroShown(state: CanvasState): CanvasState {
  return CanvasStateZod.parse({ ...state, intro_shown_session: "true" });
}

/**
 * Convenience: mark that a given step intro has been shown
 */
export function markStepIntroShown(state: CanvasState, step: string): CanvasState {
  const safe = isCanonicalStepId(step) ? step : state.current_step;
  return CanvasStateZod.parse({ ...state, intro_shown_for_step: safe });
}

/**
 * Convenience: persist Step 0 stable storage line + business name
 */
export function persistStep0(state: CanvasState, step0Line: string, businessName: string): CanvasState {
  const step_0_final = String(step0Line ?? "").trim();
  const business_name = String(businessName ?? "").trim() || "TBD";
  return CanvasStateZod.parse({
    ...state,
    step_0_final: step_0_final || state.step_0_final,
    business_name,
  });
}

/**
 * Convenience: persist Dream final (only when provided)
 */
export function persistDream(state: CanvasState, dreamLine: string): CanvasState {
  const dream_final = String(dreamLine ?? "").trim();
  return CanvasStateZod.parse({
    ...state,
    dream_final: dream_final || state.dream_final,
  });
}

/**
 * Canonical finals keys (stable field ids for recap / "facts so far").
 * Used by orchestration to pass only non-empty finals into specialist context.
 */
export const FINALS_KEYS = [
  "business_name",
  "step_0_final",
  "dream_final",
  "purpose_final",
  "bigwhy_final",
  "role_final",
  "entity_final",
  "strategy_final",
  "targetgroup_final",
  "productsservices_final",
  "rulesofthegame_final",
  "presentation_brief_final",
] as const;

export type FinalsKey = (typeof FINALS_KEYS)[number];

/**
 * Returns a snapshot of all finals that have a non-empty value.
 * Used for recap and to pass "finals so far" into every step.
 * Steps with no final value must NOT appear in the recap; this helper enforces that.
 */
export function getFinalsSnapshot(state: CanvasState): Record<string, string> {
  const out: Record<string, string> = {};
  for (const k of FINALS_KEYS) {
    const v = String((state as Record<string, unknown>)[k] ?? "").trim();
    if (!v) continue;
    if (k === "business_name" && v === "TBD") continue; // placeholder, not a final
    out[k] = v;
  }
  return out;
}
